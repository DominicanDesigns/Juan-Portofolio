# File Format Converter

**Descripción**: High utility micro-service
**Público**: General Public
**Tecnología**: Python, Flask
**Tipo**: Aplicación WEB

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
