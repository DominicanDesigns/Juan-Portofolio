# Project Planner

**Description**: Automated Project Planner solution  
**Target Audience**: Businesses/Freelancers  
**Tech Stack**: Python, Flask/FastAPI  
**Difficulty**: Media-Difficil  
**Monetization**: Licence/SaaS  
**Where to Sell**: Gumroad/Direct  
**Value Proposition**: Efficiency/Organization

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
