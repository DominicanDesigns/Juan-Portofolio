# AI Voice Assistant

**Description**: Comandos por voz  
**Target Audience**: Usuarios tech  
**Tech Stack**: Python, Speech  
**Difficulty**: Difícil | 12 días  
**Monetization**: Licencia  
**Where to Sell**: Directo  
**Value Proposition**: Automatización

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
