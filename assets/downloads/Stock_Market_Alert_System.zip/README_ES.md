# Stock Market Alert System

**Descripción**: Financial analysis and tracking
**Público**: Traders/Investors
**Tecnología**: Python, Pandas, APIs
**Tipo**: Aplicación WEB

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
