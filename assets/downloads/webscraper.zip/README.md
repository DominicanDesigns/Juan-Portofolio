# 🕸️ Web Scraping & Data Delivery (Async)

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

This script uses **Playwright** to scrape product data (Title, Price) from dynamic websites and exports it to **Excel/CSV**.

### 🛠️ Installation

1.  **Install dependencies**:
    ```bash
    pip install -r requirements.txt
    ```
2.  **Install Browsers**:
    ```bash
    playwright install chromium
    ```

### 🚀 Usage

1.  Open `scraper.py` and set `TARGET_URL` to your desired website.
2.  **Crucial**: Update `product_selector`, `title_selector`, and `price_selector` to match the website's CSS.
3.  Run the script:
    ```bash
    python scraper.py
    ```

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Este script utiliza **Playwright** para extraer datos de productos (Título, Precio) de sitios web dinámicos y los exporta automáticamente a **Excel/CSV**.

### 🛠️ Instalación

1.  **Instalar dependencias**:
    ```bash
    pip install -r requirements.txt
    ```
2.  **Instalar Navegadores**:
    (Necesario para que Playwright controle el navegador)
    ```bash
    playwright install chromium
    ```

### 🚀 Uso

1.  Abre `scraper.py` y cambia `TARGET_URL` al sitio web que deseas analizar.
2.  **Importante**: Necesitas actualizar las variables `product_selector`, `title_selector`, y `price_selector` para que coincidan con el código CSS de la página web.
3.  Ejecuta el script:
    ```bash
    python scraper.py
    ```
4.  Los archivos `products_data.csv` y `.xlsx` se crearán en esta carpeta.
