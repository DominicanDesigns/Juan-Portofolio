# YouTube Comment Bot

**Descripción**: Automated interaction bot
**Público**: Community Managers
**Tecnología**: Python, API
**Tipo**: Aplicación CLI

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
