# 🧹 Desktop File Organizer

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

Your "Digital Janitor". It scans a folder (like Downloads), detects file types, and moves them into organized subfolders (Images, Documents, etc.).

### 🚀 Usage

1.  **Config**: Open `file_organizer.py` and change `TARGET_DIR` to the folder you want to clean (e.g., `C:/Users/You/Downloads`).
2.  **Run**:
    ```bash
    python file_organizer.py
    ```
3.  **Test**: If you run it without changing the path, it creates a `MessyFolder` with dummy files to demonstrate functionality.

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Tu "Conserje Digital". Escanea una carpeta (como Descargas), detecta los tipos de archivo y los mueve a subcarpetas organizadas (Imágenes, Documentos, etc.).

### 🚀 Uso

1.  **Configuración**: Abre `file_organizer.py` y cambia `TARGET_DIR` a la carpeta que quieres limpiar (ej. `C:/Users/Tu/Downloads`).
2.  **Ejecutar**:
    ```bash
    python file_organizer.py
    ```
3.  **Prueba**: Si lo ejecutas sin cambiar la ruta, creará una carpeta llamada `MessyFolder` con archivos falsos para mostrarte cómo funciona.
