from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from itsdangerous import URLSafeTimedSerializer as Serializer
from flask import current_app

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_banned = db.Column(db.Boolean, default=False)
    balance = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    products = db.relationship('Product', backref='seller', lazy=True)
    purchases = db.relationship('Transaction', backref='buyer', lazy=True)
    activity_logs = db.relationship('ActivityLog', backref='user', lazy=True)

    def get_reset_token(self, expires_sec=1800):
        s = Serializer(current_app.config['SECRET_KEY'])
        return s.dumps({'user_id': self.id}, salt='password-reset-salt')

    @staticmethod
    def verify_reset_token(token):
        s = Serializer(current_app.config['SECRET_KEY'])
        try:
            user_id = s.loads(token, salt='password-reset-salt', max_age=1800)['user_id']
        except:
            return None
        return User.query.get(user_id)

class SiteSettings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    paypal_client_id = db.Column(db.String(200), nullable=True)
    paypal_secret = db.Column(db.String(200), nullable=True)

class ActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True) # Nullable for system events or deleted users
    action = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seller_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), default='approved') # 'approved', 'pending', 'rejected'
    
    # Public Info (The "Teaser")
    codename = db.Column(db.String(100), nullable=False) # e.g. "Project ORION"
    teaser_title = db.Column(db.String(200), nullable=False) # e.g. "Automated Instagram Growth"
    teaser_description = db.Column(db.Text, nullable=False) # Vague description of outcome
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False) # Python, JS, Go, etc.
    
    # Restricted Info (The "Vault")
    real_title = db.Column(db.String(200), nullable=False) # The actual app name
    full_description = db.Column(db.Text, nullable=False) # Detailed README
    download_link = db.Column(db.String(500), nullable=False)
    
    # Visuals
    blurred_image_url = db.Column(db.String(500), nullable=True) # Public
    real_image_url = db.Column(db.String(500), nullable=True) # Private
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
