import os
import json
from datetime import datetime, timedelta
from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message
from models import db, User, Product, Transaction, SiteSettings, ActivityLog

# Initialize Flask App
app = Flask(__name__)
app.config['SECRET_KEY'] = 'sovereign_secret_key_888' # Change in production
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=30)
basedir = os.path.abspath(os.path.dirname(__file__))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize Extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

app.config['MAIL_SERVER'] = 'smtp.googlemail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.environ.get('EMAIL_USER')
app.config['MAIL_PASSWORD'] = os.environ.get('EMAIL_PASS')
mail = Mail(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Helpers ---

def has_active_license(user, product):
    """Check if user has an active 3-month license for the product."""
    if not user.is_authenticated:
        return False
    if user.is_admin:
        return True
    
    # Check for purchase within last 90 days
    cutoff_date = datetime.utcnow() - timedelta(days=90)
    purchase = Transaction.query.filter(
        Transaction.buyer_id == user.id,
        Transaction.product_id == product.id,
        Transaction.timestamp >= cutoff_date
    ).first()
    
    return purchase is not None

def seed_data():
    """Seed existing JSON data and Admin User."""
    # 1. Create Admin User
    admin = User.query.filter_by(username='Admin').first()
    if not admin:
        print("Creating Admin User...")
        hashed_pw = generate_password_hash('Juan5872890@@@@', method='pbkdf2:sha256')
        admin = User(username='Admin', email='admin@sovereign.com', password=hashed_pw, is_admin=True, balance=999999.0)
        db.session.add(admin)
        db.session.commit()
    
    # 2. Seed SiteSettings
    settings = SiteSettings.query.first()
    if not settings:
        settings = SiteSettings(paypal_client_id="", paypal_secret="")
        db.session.add(settings)
        db.session.commit()

    # 3. Seed Products from JSON
    if Product.query.count() == 0:
        print("Seeding Products from apps.json...")
        try:
            # Use absolute path relative to this script
            json_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'apps.json')
            with open(json_path, 'r', encoding='utf-8') as f:
                apps_data = json.load(f)
                
            for item in apps_data:
                # Ensure we map fields correctly
                product = Product(
                    seller_id=admin.id,
                    status='approved', # Explicitly set status
                    codename=item.get('codename', 'Unknown'),
                    teaser_title=item.get('teaser_title', 'Untitled'),
                    teaser_description=item.get('teaser_description', 'No description'),
                    price=float(item.get('price', 0.0)),
                    category=item.get('category', 'General'),
                    real_title=item.get('real_title', 'Real Title'),
                    full_description=item.get('full_description', 'Full Info'),
                    download_link=item.get('download_link', '#'),
                    blurred_image_url=item.get('blurred_image_url'),
                    real_image_url=item.get('real_image_url')
                )
                db.session.add(product)
            db.session.commit()
            print(f"Seeded {len(apps_data)} products.")
        except Exception as e:
            print(f"Error seeding data: {e}")

def log_activity(user_id, action, details=None):
    """Log a user action to the database."""
    try:
        log = ActivityLog(user_id=user_id, action=action, details=details)
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        print(f"Failed to log activity: {e}")
        db.session.rollback()


# --- Routes: Auth ---

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('register'))
            
        user_exists = User.query.filter_by(username=username).first()
        email_exists = User.query.filter_by(email=email).first()
        
        if user_exists:
            flash('Username already exists.', 'error')
            return redirect(url_for('register'))
            
        if email_exists:
            flash('Email already exists.', 'error')
            return redirect(url_for('register'))
            
        # Create new user
        hashed_pw = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password=hashed_pw, is_admin=False)
        
        db.session.add(new_user)
        db.session.commit()
        
        # Log activity
        log_activity(new_user.id, "register", "Account created")
        
        login_user(new_user)
        flash('Account created successfully!', 'success')
        return redirect(url_for('index'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.is_admin:
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            if user.is_banned:
                 flash('ACCESS DENIED: Your account has been suspended by the Administrator.', 'error')
                 log_activity(user.id, 'login_failed', 'User is banned')
                 return redirect(url_for('login'))
                 
            remember = True if request.form.get('remember') else False
            login_user(user, remember=remember)
            if user.is_admin:
                log_activity(user.id, 'login', 'Admin Login')
                return redirect(url_for('admin_dashboard'))
            
            log_activity(user.id, 'login', 'User Login')
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials.', 'error')
            if user:
                 log_activity(user.id, 'login_failed', 'Invalid Password')
            
    return render_template('login.html')

def send_reset_email(user):
    token = user.get_reset_token()
    msg = Message('Password Reset Request',
                  sender='noreply@sovereign.com',
                  recipients=[user.email])
    msg.body = f'''To reset your password, visit the following link:
{url_for('reset_token', token=token, _external=True)}

If you did not make this request then simply ignore this email and no changes will be made.
'''
    # Mock sending if no credentials
    if not app.config['MAIL_USERNAME']:
        print(f"------------ MOCK EMAIL ------------")
        print(f"To: {user.email}")
        print(f"Body: {msg.body}")
        print(f"------------------------------------")
    else:
        mail.send(msg)

@app.route("/reset_password", methods=['GET', 'POST'])
def reset_request():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        if user:
            send_reset_email(user)
        flash('An email has been sent with instructions to reset your password.', 'info')
        return redirect(url_for('login'))
    return render_template('reset_request.html')

@app.route("/reset_password/<token>", methods=['GET', 'POST'])
def reset_token(token):
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    user = User.verify_reset_token(token)
    if user is None:
        flash('That is an invalid or expired token', 'warning')
        return redirect(url_for('reset_request'))
    if request.method == 'POST':
        password = request.form.get('password')
        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        user.password = hashed_password
        db.session.commit()
        flash('Your password has been updated! You are now able to log in', 'success')
        return redirect(url_for('login'))
    return render_template('reset_token.html')



@app.route('/submit-app', methods=['GET', 'POST'])
@login_required
def submit_app():
    if request.method == 'POST':
        codename = request.form.get('codename')
        teaser_title = request.form.get('teaser_title')
        teaser_description = request.form.get('teaser_description')
        price = float(request.form.get('price'))
        category = request.form.get('category')
        real_title = request.form.get('real_title')
        full_description = request.form.get('full_description')
        download_link = request.form.get('download_link')
        
        # Determine image based on category theme
        theme_map = {
            'Software Development': 'tech',
            'Web Technologies': 'tech',
            'Data & AI': 'tech',
            'Blockchain & Web3': 'tech',
            'Mobile & Desktop': 'tech',
            'Game Development': 'tech',
            'No-Code & Automation': 'biz',
            'Business & Productivity': 'biz',
            'Finance': 'biz',
            'Creative & Design': 'creative',
            'Legacy & Enterprise': 'tech',
            'Other': 'tech'
        }
        
        # Find which group the category belongs to
        # Since we get the raw value (e.g. "Python"), we need to map it back or just map the values?
        # The form returns the Value ex: "Python". We need a reverse lookup or a simplified map.
        # Simpler approach: Map specific keywords or set default.
        
        # Comprehensive Keyword Map
        bg_theme = 'tech' # Default
        
        cat_lower = (category or '').lower()
        if any(x in cat_lower for x in ['finance', 'business', 'marketing', 'excel', 'copywriting', 'legal', 'consultation']):
            bg_theme = 'biz'
        elif any(x in cat_lower for x in ['design', 'creative', 'art', 'ui', 'ux', 'video', 'music', 'animation', '3d', 'logo', 'font']):
            bg_theme = 'creative'
        elif any(x in cat_lower for x in ['no-code', 'bubble', 'webflow', 'zapier', 'airtable']):
            bg_theme = 'biz' # Or tech? Biz fits automation tools well.
            
        # Specific override for Game Dev to be creative? or Tech? Tech fits better for engines.
        
        blurred_image_url = "/static/images/def_locked.jpg"
        real_image_url = f"/static/images/def_{bg_theme}.jpg"
        
        # Allow user URL override if valid (optional, but requested behavior implied default for new apps not in JSON)
        # We will strictly use our cool images for now as requested "newly created apps... to something cool"
        
        product = Product(
            seller_id=current_user.id,
            status='pending',
            codename=codename,
            teaser_title=teaser_title,
            teaser_description=teaser_description,
            price=price,
            category=category,
            real_title=real_title,
            full_description=full_description,
            download_link=download_link,
            blurred_image_url=blurred_image_url,
            real_image_url=real_image_url
        )
        db.session.add(product)
        db.session.commit()
        log_activity(current_user.id, 'submit_app', f'Submitted {real_title}')
        flash('App submitted for approval. Access granted upon visualization.', 'success')
        return redirect(url_for('index'))
        
    return render_template('submit_app.html')

@app.route('/u/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    # Only show approved products
    products = Product.query.filter_by(seller_id=user.id, status='approved').all()
    return render_template('profile.html', user=user, products=products)

@app.route('/admin/bulk-upload', methods=['POST'])
@login_required
def admin_bulk_upload():
    if not current_user.is_admin:
        return redirect(url_for('index'))
        
    if 'file' not in request.files:
        flash('No file part', 'error')
        return redirect(url_for('admin_dashboard'))
        
    file = request.files['file']
    if file.filename == '':
        flash('No selected file', 'error')
        return redirect(url_for('admin_dashboard'))
        
    if file:
        try:
            apps_data = json.load(file)
            count = 0
            for item in apps_data:
                product = Product(
                    seller_id=current_user.id,
                    status='approved',
                    codename=item.get('codename', 'Unknown'),
                    teaser_title=item.get('teaser_title', 'Untitled'),
                    teaser_description=item.get('teaser_description', 'No description'),
                    price=float(item.get('price', 0.0)),
                    category=item.get('category', 'General'),
                    real_title=item.get('real_title', 'Real Title'),
                    full_description=item.get('full_description', 'Full Info'),
                    download_link=item.get('download_link', '#'),
                    blurred_image_url=item.get('blurred_image_url'),
                    real_image_url=item.get('real_image_url')
                )
                db.session.add(product)
                count += 1
            db.session.commit()
            log_activity(current_user.id, 'bulk_upload', f'Uploaded {count} apps')
            flash(f'Successfully uploaded {count} apps.', 'success')
        except Exception as e:
            flash(f'Error processing file: {e}', 'error')
            
    return redirect(url_for('admin_dashboard'))

@app.route('/forgot-password')
def forgot_password():
    return redirect(url_for('reset_request'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# --- Routes: Admin ---

@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        abort(403)
        
    products = Product.query.all()
    transactions = Transaction.query.order_by(Transaction.timestamp.desc()).limit(50).all()
    users = User.query.all()
    
    return render_template('admin.html', products=products, transactions=transactions, users=users)

@app.route('/admin/user/<int:user_id>/ban')
@login_required
def ban_user(user_id):
    if not current_user.is_admin: abort(403)
    user = User.query.get_or_404(user_id)
    if not user.is_admin: # Safety: don't ban admin
        user.is_banned = True
        db.session.commit()
        flash(f'User {user.username} banned.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/user/<int:user_id>/unban')
@login_required
def unban_user(user_id):
    if not current_user.is_admin: abort(403)
    user = User.query.get_or_404(user_id)
    user.is_banned = False
    db.session.commit()
    flash(f'User {user.username} unbanned.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/user/<int:user_id>/delete')
@login_required
def delete_user(user_id):
    if not current_user.is_admin: abort(403)
    user = User.query.get_or_404(user_id)
    if not user.is_admin:
        db.session.delete(user)
        db.session.commit()
        flash(f'User {user.username} deleted.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/product/<int:product_id>/edit', methods=['POST'])
@login_required
def edit_product(product_id):
    if not current_user.is_admin: abort(403)
    product = Product.query.get_or_404(product_id)
    
    product.teaser_title = request.form.get('teaser_title')
    product.price = float(request.form.get('price'))
    product.real_title = request.form.get('real_title')
    product.download_link = request.form.get('download_link')
    
    # New Fields
    product.codename = request.form.get('codename')
    product.category = request.form.get('category')
    product.teaser_description = request.form.get('teaser_description')
    product.full_description = request.form.get('full_description')
    product.blurred_image_url = request.form.get('blurred_image_url')
    product.real_image_url = request.form.get('real_image_url')
    
    # Optional status update if provided
    status = request.form.get('status')
    if status:
        product.status = status
    
    db.session.commit()
    flash(f'Asset {product.codename} updated successfully.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/product/<int:product_id>/delete')
@login_required
def delete_product(product_id):
    if not current_user.is_admin: abort(403)
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash('Product deleted.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/settings', methods=['POST'])
@login_required
def update_settings():
    if not current_user.is_admin: abort(403)
    
    client_id = request.form.get('paypal_client_id')
    secret = request.form.get('paypal_secret')
    
    settings = SiteSettings.query.first()
    if not settings:
        settings = SiteSettings()
        db.session.add(settings)
        
    if client_id:
        settings.paypal_client_id = client_id
    if secret: # Only update if provided (allows showing placeholder in UI)
        settings.paypal_secret = secret
        
    db.session.commit()
    flash('Payment settings updated.', 'success')
    return redirect(url_for('admin_dashboard'))

# --- Routes: Store ---

@app.route('/')
def index():
    query = request.args.get('q')
    category = request.args.get('category')
    
    products_query = Product.query
    
    if query:
        search = f"%{query}%"
        products_query = products_query.filter(
            (Product.real_title.ilike(search)) | 
            (Product.codename.ilike(search)) | 
            (Product.teaser_description.ilike(search))
        )
    
    if category and category != 'All':
        products_query = products_query.filter_by(category=category)
        
    products = products_query.all()
    # Pre-calculate access for template if user is logged in
    # (Or handle in template with a custom filter, but simpler to just pass a set of IDs)
    owned_ids = []
    if current_user.is_authenticated:
        # Get all valid purchases
        cutoff_date = datetime.utcnow() - timedelta(days=90)
        transactions = Transaction.query.filter(
            Transaction.buyer_id == current_user.id,
            Transaction.timestamp >= cutoff_date
        ).all()
        owned_ids = [t.product_id for t in transactions]
        
    return render_template('index.html', products=products, owned_ids=owned_ids)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    has_access = has_active_license(current_user, product)
    
    settings = SiteSettings.query.first()
    paypal_client_id = settings.paypal_client_id if settings else ""
    
    return render_template('product_detail.html', product=product, has_access=has_access, paypal_client_id=paypal_client_id)

@app.route('/api/buy/<int:product_id>', methods=['POST'])
@login_required
def buy_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    # In a real app, verify PayPal/Stripe payment token here.
    # For now, we trust the "payment_result" from the frontend or just mock it if it's the simple flow.
    
    # Mock Purchase / Record Transaction
    transaction = Transaction(
        buyer_id=current_user.id,
        product_id=product.id,
        amount=product.price
    )
    db.session.add(transaction)
    
    # Revenue Split
    seller = product.seller
    admin = User.query.filter_by(username='Admin').first()
    
    if seller.is_admin:
        seller.balance += product.price
    else:
        # 95% to seller, 5% to Admin
        seller_share = product.price * 0.95
        admin_share = product.price * 0.05
        
        seller.balance += seller_share
        if admin:
            admin.balance += admin_share
            
    db.session.commit()
    
    flash(f'Transaction Successful! You have access to {product.real_title} for 90 days.', 'success')
    return jsonify({'success': True, 'message': 'Purchase successful'})

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True, port=5000)
