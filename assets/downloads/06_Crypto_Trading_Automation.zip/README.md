# 🪙 Crypto Trading Bot (Paper Trading)

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

A real-time crypto bot using **CCXT**. It fetches live data from Binance and simulates trades ("Paper Trading") based on a Simple Moving Average (SMA) strategy.

### 🚀 Usage

1.  **Install**: `pip install -r requirements.txt`.
2.  **Run**:
    ```bash
    python trading_bot.py
    ```
3.  The bot will print price updates and simulated Buy/Sell signals every minute.

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Un bot de criptomonedas en tiempo real usando **CCXT**. Obtiene datos en vivo de Binance y simula operaciones ("Paper Trading") basándose en una estrategia de Media Móvil Simple (SMA). No usa dinero real por defecto.

### 🚀 Uso

1.  **Instalar**: `pip install -r requirements.txt`.
2.  **Ejecutar**:
    ```bash
    python trading_bot.py
    ```
3.  El bot imprimirá actualizaciones de precio y señales de Compra/Venta simuladas cada minuto.
