# Quiz Master Pro

**Description**: Entertainment and logic
**Target Audience**: Gamers
**Tech Stack**: Python, Pygame/Logic
**Type**: CLI Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
