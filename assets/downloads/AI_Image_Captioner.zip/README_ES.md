# AI Image Captioner

**Descripción**: Describe imágenes  
**Público Objetivo**: Accesibilidad  
**Tecnología**: Python, CV  
**Dificultad**: Media | 6 días  
**Monetización**: Licencia  
**Precio Sugerido**: $45  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Inclusión

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
