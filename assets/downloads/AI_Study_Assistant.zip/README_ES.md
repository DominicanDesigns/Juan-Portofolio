# AI Study Assistant

**Descripción**: Ayuda académica  
**Público Objetivo**: Estudiantes  
**Tecnología**: Python  
**Dificultad**: Media | 6 días  
**Monetización**: Freemium  
**Precio Sugerido**: $30  
**Dónde Vender**: Play Store  
**Propuesta de Valor**: Bajo rendimiento

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
