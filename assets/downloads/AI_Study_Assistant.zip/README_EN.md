# AI Study Assistant

**Description**: Ayuda académica  
**Target Audience**: Estudiantes  
**Tech Stack**: Python  
**Difficulty**: Media | 6 días  
**Monetization**: Freemium  
**Where to Sell**: Play Store  
**Value Proposition**: Bajo rendimiento

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
