# AI Cover Letter Generator

**Descripción**: Cartas personalizadas  
**Público Objetivo**: Profesionales  
**Tecnología**: Python, OpenAI  
**Dificultad**: Fácil | 3 días  
**Monetización**: Créditos  
**Precio Sugerido**: $29  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Ahorra tiempo

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
