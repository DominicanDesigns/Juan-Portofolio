# Google Maps Extractor

**Descripción**: Advanced web scraping automation
**Público**: Data Analysts
**Tecnología**: Python, Selenium/BS4
**Tipo**: Aplicación WEB

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
