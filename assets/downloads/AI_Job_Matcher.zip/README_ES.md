# AI Job Matcher

**Descripción**: Ofertas compatibles  
**Público Objetivo**: Desempleados  
**Tecnología**: Python, ML  
**Dificultad**: Media | 7 días  
**Monetización**: Suscripción  
**Precio Sugerido**: $10/mes  
**Dónde Vender**: Web  
**Propuesta de Valor**: Buscar trabajo

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
