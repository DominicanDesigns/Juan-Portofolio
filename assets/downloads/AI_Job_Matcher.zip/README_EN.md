# AI Job Matcher

**Description**: Ofertas compatibles  
**Target Audience**: Desempleados  
**Tech Stack**: Python, ML  
**Difficulty**: Media | 7 días  
**Monetization**: Suscripción  
**Where to Sell**: Web  
**Value Proposition**: Buscar trabajo

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
