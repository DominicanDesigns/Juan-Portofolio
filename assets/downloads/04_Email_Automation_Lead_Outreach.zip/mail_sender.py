import smtplib
import csv
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from jinja2 import Environment, FileSystemLoader

# --- CONFIGURATION ---
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
EMAIL_ADDRESS = 'your_email@gmail.com'
EMAIL_PASSWORD = 'your_app_password' 

TEMPLATE_FILE = 'email_template.html'
CONTACTS_FILE = 'contacts.csv'
SUBJECT = "Exclusive Offer for {{Company}}"

def send_emails():
    env = Environment(loader=FileSystemLoader('.'))
    try:
        template = env.get_template(TEMPLATE_FILE)
    except Exception as e:
        print(f"❌ Could not load template: {e}")
        return

    if not os.path.exists(CONTACTS_FILE):
        print(f"❌ Contacts file '{CONTACTS_FILE}' not found.")
        return

    contacts = []
    with open(CONTACTS_FILE, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            contacts.append(row)

    print(f"📧 Found {len(contacts)} contacts. Connecting to SMTP...")

    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        print("✅ Login Successful.")
    except Exception as e:
        print(f"❌ SMTP Connection Failed. Check credentials.\nError: {e}")
        return

    for person in contacts:
        try:
            body_html = template.render(person)
            subject = SUBJECT.replace("{{Company}}", person.get('Company', 'You'))

            msg = MIMEMultipart()
            msg['From'] = EMAIL_ADDRESS
            msg['To'] = person['Email']
            msg['Subject'] = subject
            msg.attach(MIMEText(body_html, 'html'))

            server.send_message(msg)
            print(f"   🚀 Sent to: {person['Email']}")
        except Exception as e:
            print(f"   ⚠️ Failed to send to {person.get('Email')}: {e}")

    server.quit()
    print("🏁 Done.")

if __name__ == "__main__":
    send_emails()
