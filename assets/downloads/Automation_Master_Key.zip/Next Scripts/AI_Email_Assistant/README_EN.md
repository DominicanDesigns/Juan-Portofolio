# AI Email Assistant

**Description**: Respuestas automáticas  
**Target Audience**: Freelancers  
**Tech Stack**: Python, Gmail API  
**Difficulty**: Media | 6 días  
**Monetization**: Suscripción  
**Where to Sell**: SaaS  
**Value Proposition**: Saturación de correos

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
