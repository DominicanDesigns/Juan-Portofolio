# AI Cover Letter Generator

**Description**: Cartas personalizadas  
**Target Audience**: Profesionales  
**Tech Stack**: Python, OpenAI  
**Difficulty**: Fácil | 3 días  
**Monetization**: Créditos  
**Where to Sell**: Gumroad  
**Value Proposition**: Ahorra tiempo

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
