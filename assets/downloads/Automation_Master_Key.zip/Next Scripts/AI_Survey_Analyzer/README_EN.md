# AI Survey Analyzer

**Description**: Analiza encuestas  
**Target Audience**: Investigadores  
**Tech Stack**: Python, Pandas  
**Difficulty**: Media | 5 días  
**Monetization**: Licencia  
**Where to Sell**: Gumroad  
**Value Proposition**: Datos crudos

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
