# AI Survey Analyzer

**Descripción**: Analiza encuestas  
**Público Objetivo**: Investigadores  
**Tecnología**: Python, Pandas  
**Dificultad**: Media | 5 días  
**Monetización**: Licencia  
**Precio Sugerido**: $40  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Datos crudos

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
