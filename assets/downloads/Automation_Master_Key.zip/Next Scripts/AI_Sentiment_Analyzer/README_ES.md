# AI Sentiment Analyzer

**Descripción**: Analiza opiniones  
**Público Objetivo**: Empresas  
**Tecnología**: Python, ML  
**Dificultad**: Media | 5 días  
**Monetización**: Licencia  
**Precio Sugerido**: $30  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Feedback confuso

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
