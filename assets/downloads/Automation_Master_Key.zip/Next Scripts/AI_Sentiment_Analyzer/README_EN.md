# AI Sentiment Analyzer

**Description**: Analiza opiniones  
**Target Audience**: Empresas  
**Tech Stack**: Python, ML  
**Difficulty**: Media | 5 días  
**Monetization**: Licencia  
**Where to Sell**: Gumroad  
**Value Proposition**: Feedback confuso

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
