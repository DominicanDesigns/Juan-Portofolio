# AI Learning Planner

**Descripción**: Planes de estudio  
**Público Objetivo**: Estudiantes  
**Tecnología**: Python  
**Dificultad**: Media | 5 días  
**Monetización**: Freemium  
**Precio Sugerido**: $25  
**Dónde Vender**: App  
**Propuesta de Valor**: Desorganización

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
