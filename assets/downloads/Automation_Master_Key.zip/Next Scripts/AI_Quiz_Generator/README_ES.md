# AI Quiz Generator

**Descripción**: Quizzes automáticos  
**Público Objetivo**: Profesores  
**Tecnología**: Python  
**Dificultad**: Fácil | 3 días  
**Monetización**: Licencia  
**Precio Sugerido**: $35  
**Dónde Vender**: Educativo  
**Propuesta de Valor**: Evaluaciones

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
