# AI Meeting Summarizer

**Description**: Resume reuniones  
**Target Audience**: Equipos remotos  
**Tech Stack**: Python, Speech API  
**Difficulty**: Media | 6 días  
**Monetization**: Suscripción  
**Where to Sell**: SaaS  
**Value Proposition**: Reuniones largas

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
