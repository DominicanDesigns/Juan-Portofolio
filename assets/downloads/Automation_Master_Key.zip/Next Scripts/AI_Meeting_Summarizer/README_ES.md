# AI Meeting Summarizer

**Descripción**: Resume reuniones  
**Público Objetivo**: Equipos remotos  
**Tecnología**: Python, Speech API  
**Dificultad**: Media | 6 días  
**Monetización**: Suscripción  
**Precio Sugerido**: $10/mes  
**Dónde Vender**: SaaS  
**Propuesta de Valor**: Reuniones largas

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
