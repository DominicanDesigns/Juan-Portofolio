# AI Logo Generator

**Description**: Logos automáticos  
**Target Audience**: Startups  
**Tech Stack**: Python, CV  
**Difficulty**: Media | 6 días  
**Monetization**: Créditos  
**Where to Sell**: Web  
**Value Proposition**: Branding caro

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
