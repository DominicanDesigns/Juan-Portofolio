# Color Palette Generator

**Description**: Developer productivity tool
**Target Audience**: Developers
**Tech Stack**: Python, Utilities
**Type**: WEB Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
