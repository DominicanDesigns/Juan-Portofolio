# AI Chat SaaS Template

**Description**: Plantilla SaaS IA  
**Target Audience**: Emprendedores  
**Tech Stack**: Python, FastAPI  
**Difficulty**: Difícil | 14 días  
**Monetization**: Código fuente  
**Where to Sell**: Gumroad  
**Value Proposition**: Lanzar rápido

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
