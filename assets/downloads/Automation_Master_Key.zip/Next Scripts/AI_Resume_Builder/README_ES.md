# AI Resume Builder

**Descripción**: CV profesionales  
**Público Objetivo**: Jóvenes  
**Tecnología**: Python  
**Dificultad**: Fácil | 4 días  
**Monetización**: Pago único  
**Precio Sugerido**: $20  
**Dónde Vender**: Etsy  
**Propuesta de Valor**: Mala presentación

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
