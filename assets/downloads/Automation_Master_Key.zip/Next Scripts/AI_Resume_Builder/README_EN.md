# AI Resume Builder

**Description**: CV profesionales  
**Target Audience**: Jóvenes  
**Tech Stack**: Python  
**Difficulty**: Fácil | 4 días  
**Monetization**: Pago único  
**Where to Sell**: Etsy  
**Value Proposition**: Mala presentación

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
