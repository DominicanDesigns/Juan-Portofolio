# AI Stock Predictor

**Descripción**: Predice tendencias  
**Público Objetivo**: Traders  
**Tecnología**: Python, ML  
**Dificultad**: Difícil | 12 días  
**Monetización**: Suscripción  
**Precio Sugerido**: $30/mes  
**Dónde Vender**: Web  
**Propuesta de Valor**: Riesgo

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
