# AI Stock Predictor

**Description**: Predice tendencias  
**Target Audience**: Traders  
**Tech Stack**: Python, ML  
**Difficulty**: Difícil | 12 días  
**Monetization**: Suscripción  
**Where to Sell**: Web  
**Value Proposition**: Riesgo

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
