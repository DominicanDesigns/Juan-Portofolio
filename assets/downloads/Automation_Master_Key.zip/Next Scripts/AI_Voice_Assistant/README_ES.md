# AI Voice Assistant

**Descripción**: Comandos por voz  
**Público Objetivo**: Usuarios tech  
**Tecnología**: Python, Speech  
**Dificultad**: Difícil | 12 días  
**Monetización**: Licencia  
**Precio Sugerido**: $150  
**Dónde Vender**: Directo  
**Propuesta de Valor**: Automatización

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
