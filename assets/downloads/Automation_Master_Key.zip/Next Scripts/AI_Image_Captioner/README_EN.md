# AI Image Captioner

**Description**: Describe imágenes  
**Target Audience**: Accesibilidad  
**Tech Stack**: Python, CV  
**Difficulty**: Media | 6 días  
**Monetization**: Licencia  
**Where to Sell**: Gumroad  
**Value Proposition**: Inclusión

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
