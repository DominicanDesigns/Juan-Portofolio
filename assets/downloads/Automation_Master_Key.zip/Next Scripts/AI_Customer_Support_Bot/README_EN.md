# AI Customer Support Bot

**Description**: Soporte automatizado  
**Target Audience**: Negocios  
**Tech Stack**: Python  
**Difficulty**: Media | 7 días  
**Monetization**: Suscripción  
**Where to Sell**: SaaS  
**Value Proposition**: Costos altos

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
