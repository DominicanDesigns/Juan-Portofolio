# AI Interview Prep Tool

**Descripción**: Preguntas por rol  
**Público Objetivo**: Estudiantes  
**Tecnología**: Python, NLP  
**Dificultad**: Fácil | 4 días  
**Monetización**: Pago único  
**Precio Sugerido**: $25  
**Dónde Vender**: Etsy  
**Propuesta de Valor**: Nervios en entrevistas

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
