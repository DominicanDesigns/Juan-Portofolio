# AI Fake Review Detector

**Description**: Detecta reseñas falsas  
**Target Audience**: E-commerce  
**Tech Stack**: Python, ML  
**Difficulty**: Media | 7 días  
**Monetization**: Licencia  
**Where to Sell**: B2B  
**Value Proposition**: Fraude

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
