# AI Fake Review Detector

**Descripción**: Detecta reseñas falsas  
**Público Objetivo**: E-commerce  
**Tecnología**: Python, ML  
**Dificultad**: Media | 7 días  
**Monetización**: Licencia  
**Precio Sugerido**: $60  
**Dónde Vender**: B2B  
**Propuesta de Valor**: Fraude

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
