import asyncio
import pandas as pd
from playwright.async_api import async_playwright
import datetime

# --- CONFIGURATION ---
TARGET_URL = 'https://web-scraping.dev/products' # Example target
OUTPUT_FILE = 'products_data' # No extension needed, will add .csv and .xlsx
HEADLESS = True

async def scrape_products():
    """
    Scrapes product data from the target website using Playwright.
    """
    print(f"🚀 Starting scraper for: {TARGET_URL}")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=HEADLESS)
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        )
        page = await context.new_page()

        try:
            await page.goto(TARGET_URL, timeout=60000)
            await page.wait_for_load_state('networkidle')

            # --- SELECTORS (Update these based on the actual target site) ---
            product_selector = '.product-item, .product-card, .col-md-4' 
            title_selector = 'h3, .product-title, .title'
            price_selector = '.price, span.amount'
            
            try:
                await page.wait_for_selector(product_selector, timeout=10000)
            except:
                print("⚠️ No products found immediately. Check selectors.")

            products = await page.locator(product_selector).all()
            print(f"📦 Found {len(products)} potential product items.")

            scraped_data = []

            for i, product in enumerate(products):
                try:
                    title = await product.locator(title_selector).first.inner_text()
                    price = await product.locator(price_selector).first.inner_text()
                    
                    title = title.strip()
                    price = price.strip().replace('\n', '')

                    scraped_data.append({
                        'Title': title,
                        'Price': price,
                        'Date Scraped': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    })
                    print(f"   ✅ Scraped: {title} - {price}")
                except:
                    continue

            return scraped_data

        except Exception as e:
            print(f"❌ Error during scraping: {e}")
            return []
        finally:
            await browser.close()

def save_data(data):
    if not data:
        print("⚠️ No data to save.")
        return

    df = pd.DataFrame(data)

    csv_filename = f"{OUTPUT_FILE}.csv"
    df.to_csv(csv_filename, index=False, encoding='utf-8')
    print(f"💾 Data saved to: {csv_filename}")

    xlsx_filename = f"{OUTPUT_FILE}.xlsx"
    try:
        df.to_excel(xlsx_filename, index=False)
        print(f"💾 Data saved to: {xlsx_filename}")
    except Exception as e:
        print(f"⚠️ Could not save Excel (missing openpyxl?): {e}")

if __name__ == "__main__":
    data = asyncio.run(scrape_products())
    save_data(data)
