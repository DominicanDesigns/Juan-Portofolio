import ccxt
import time
import pandas as pd
from datetime import datetime

# --- CONFIGURATION ---
EXCHANGE_ID = 'binance' 
SYMBOL = 'BTC/USDT'
TIMEFRAME = '1m' 
SMA_PERIOD = 5   
CHECK_INTERVAL_SEC = 60

position = None 
entry_price = 0.0

def initialize_exchange():
    try:
        exchange_class = getattr(ccxt, EXCHANGE_ID)
        exchange = exchange_class({'enableRateLimit': True})
        return exchange
    except Exception as e:
        print(f"❌ Error initializing exchange: {e}")
        return None

def fetch_data(exchange):
    try:
        ohlcv = exchange.fetch_ohlcv(SYMBOL, TIMEFRAME, limit=SMA_PERIOD + 5)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        return df
    except Exception as e:
        print(f"⚠️ Error fetching data: {e}")
        return None

def calculate_indicators(df):
    df['SMA'] = df['close'].rolling(window=SMA_PERIOD).mean()
    return df

def run_bot():
    global position, entry_price
    exchange = initialize_exchange()
    
    print(f"🚀 Crypto Bot Started ({EXCHANGE_ID.upper()}: {SYMBOL})")
    
    while True:
        df = fetch_data(exchange)
        if df is not None:
            df = calculate_indicators(df)
            latest = df.iloc[-1]
            last_price = latest['close']
            sma = latest['SMA']
            timestamp = latest['timestamp'].strftime('%H:%M:%S')

            print(f"[{timestamp}] Price: ${last_price:.2f} | SMA: ${sma:.2f}")

            if position is None and last_price > sma:
                position = 'LONG'
                entry_price = last_price
                print(f"🟢 BUY SIGNAL! ${last_price:.2f}")

            elif position == 'LONG' and last_price < sma:
                position = None
                pnl = last_price - entry_price
                print(f"🔴 SELL SIGNAL! ${last_price:.2f} | PnL: ${pnl:.2f}")

        time.sleep(CHECK_INTERVAL_SEC)

if __name__ == "__main__":
    run_bot()
