# 📊 Excel & Data Reporting Automation

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

Takes a raw CSV file (`raw_sales_data.csv`), cleans the data (fixes missing values), calculates totals, and generates a formatted professional Excel report (`Monthly_Sales_Report.xlsx`).

### 🚀 Usage

1.  **Install**: `pip install -r requirements.txt`.
2.  **Run**:
    ```bash
    python report_generator.py
    ```
3.  **Note**: If no CSV exists, the script creates a dummy one for you to test.

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Toma un archivo CSV "sucio" (`raw_sales_data.csv`), limpia los datos (arregla valores faltantes), calcula totales y genera un reporte de Excel profesional y formateado (`Monthly_Sales_Report.xlsx`).

### 🚀 Uso

1.  **Instalar**: `pip install -r requirements.txt`.
2.  **Ejecutar**:
    ```bash
    python report_generator.py
    ```
3.  **Nota**: Si no existe el archivo CSV, el script creará uno de prueba automáticamente para que veas cómo funciona.
