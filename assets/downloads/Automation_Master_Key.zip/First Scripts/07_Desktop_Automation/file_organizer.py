import os
import shutil
from pathlib import Path

# --- CONFIGURATION ---
TARGET_DIR = 'MessyFolder'

DIRECTORIES = {
    "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg"],
    "Documents": [".pdf", ".docx", ".txt", ".xlsx", ".pptx", ".csv"],
    "Archives": [".zip", ".rar", ".tar", ".gz"],
    "Installers": [".exe", ".msi", ".dmg"],
    "Code": [".py", ".js", ".html", ".css", ".java"],
    "Audio": [".mp3", ".wav"],
    "Video": [".mp4", ".mkv", ".mov"]
}

def create_dummy_mess():
    if not os.path.exists(TARGET_DIR):
        os.makedirs(TARGET_DIR)
        print(f"🧪 Creating test files in '{TARGET_DIR}'...")
        Path(f"{TARGET_DIR}/photo.jpg").touch()
        Path(f"{TARGET_DIR}/report.pdf").touch()
        Path(f"{TARGET_DIR}/installer.exe").touch()

def organize_files():
    target_path = Path(TARGET_DIR)
    
    if not target_path.exists():
        create_dummy_mess()

    print(f"🧹 Organizing folder: {target_path.resolve()}")

    for item in target_path.iterdir():
        if item.is_dir():
            continue

        file_ext = item.suffix.lower()
        if not file_ext:
            continue 

        destination_folder = "Others"

        for folder, extensions in DIRECTORIES.items():
            if file_ext in extensions:
                destination_folder = folder
                break
        
        folder_path = target_path / destination_folder
        folder_path.mkdir(exist_ok=True)

        try:
            target_file_path = folder_path / item.name
            shutil.move(str(item), str(target_file_path))
            print(f"   Moved: {item.name} -> {destination_folder}/")
        except Exception as e:
            print(f"   ❌ Error moving {item.name}: {e}")

    print("✨ Cleanup Complete!")

if __name__ == "__main__":
    organize_files()
