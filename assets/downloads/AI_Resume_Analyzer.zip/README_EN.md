# AI Resume Analyzer

**Description**: Analiza CV para ATS  
**Target Audience**: Buscadores de empleo  
**Tech Stack**: Python, NLP, Flask  
**Difficulty**: Media | 5–7 días  
**Monetization**: Licencia  
**Where to Sell**: Gumroad  
**Value Proposition**: Rechazos automáticos

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
