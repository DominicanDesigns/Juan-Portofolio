# AI Resume Analyzer

**Descripción**: Analiza CV para ATS  
**Público Objetivo**: Buscadores de empleo  
**Tecnología**: Python, NLP, Flask  
**Dificultad**: Media | 5–7 días  
**Monetización**: Licencia  
**Precio Sugerido**: $39  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Rechazos automáticos

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
