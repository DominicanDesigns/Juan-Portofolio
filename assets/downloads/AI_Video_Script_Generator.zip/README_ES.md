# AI Video Script Generator

**Descripción**: Guiones automáticos  
**Público Objetivo**: YouTubers  
**Tecnología**: Python  
**Dificultad**: Fácil | 3 días  
**Monetización**: Créditos  
**Precio Sugerido**: $30  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Creatividad

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
