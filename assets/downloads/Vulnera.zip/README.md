# Monster HackerOne Vulnerability Scanner

## 🇺🇸 English

This tool is a "Monster" edition vulnerability scanner designed for ethical hackers and bug bounty hunters. It automates recent reconnaissance, security header analysis, and Proof-of-Concept (PoC) generation for HackerOne reports.

### Features

- **Deep Header Analysis**: Checks for Clickjacking, HSTS, XSS protection, and more.
- **CORS Verification**: Detects insecure Access-Control-Allow-Origin settings.
- **Sensitive File Hunter**: Scans for .env, backups, git repositories, and more.
- **Auto-PoC**: Automatically generates HTML files to demonstrate Clickjacking vulnerabilities.
- **Professional Reporting**: Generates a ready-to-submit Markdown report.

### Installation

1. Install Python 3.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Usage

Run the script and follow the prompts:

```bash
python monster_scan.py
```

Or pass the URL directly:

```bash
python monster_scan.py https://example.com
```

---

## 🇪🇸 Español

Esta herramienta es un escáner de vulnerabilidades "Monstruo" diseñado para hackers éticos y cazadores de recompensas (bug bounty). Automatiza el reconocimiento, el análisis de cabeceras de seguridad y la generación de Pruebas de Concepto (PoC) para reportes de HackerOne.

### Características

- **Análisis Profundo de Cabeceras**: Verifica Clickjacking, HSTS, protección XSS, y más.
- **Verificación CORS**: Detecta configuraciones inseguras de Access-Control-Allow-Origin.
- **Cazador de Archivos Sensibles**: Busca .env, backups, repositorios git, y más.
- **Auto-PoC**: Genera automáticamente archivos HTML para demostrar vulnerabilidades de Clickjacking.
- **Reporte Profesional**: Genera un reporte en Markdown listo para enviar.

### Instalación

1. Instala Python 3.
2. Instala las dependencias:
   ```bash
   pip install -r requirements.txt
   ```

### Uso

Ejecuta el script y sigue las instrucciones:

```bash
python monster_scan.py
```

O pasa la URL directamente:

```bash
python monster_scan.py https://ejemplo.com
```

### ⚠️ Disclaimer / Descargo de Responsabilidad

**English**: This tool is for educational and ethical testing purposes only. Usage on targets without prior mutual consent is illegal.
**Español**: Esta herramienta es solo para fines educativos y de pruebas éticas. El uso en objetivos sin consentimiento mutuo previo es ilegal.
