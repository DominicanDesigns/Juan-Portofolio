import requests
import colorama
from colorama import Fore, Style
import tldextract
import os
import sys
import datetime
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

# Initialize Colorama
colorama.init(autoreset=True)

# ------------------------------------------------------------------------------
# CONFIGURATION & CONSTANTS
# ------------------------------------------------------------------------------
HEADERS_USER_AGENT = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

SENSITIVE_FILES = [
    'robots.txt',
    'sitemap.xml',
    '.env',
    '.git/HEAD',
    '.git/config',
    'ads.txt',
    'security.txt',
    '.well-known/security.txt',
    'backup.zip',
    'backup.sql'
]

# ------------------------------------------------------------------------------
# UI & UTILS
# ------------------------------------------------------------------------------
def print_banner():
    banner = rf"""
{Fore.RED}    __  ___                 __              
   /  |/  /___  ____  _____/ /____  _____   
  / /|_/ / __ \/ __ \/ ___/ __/ _ \/ ___/   
 / /  / / /_/ / / / (__  ) /_/  __/ /       
/_/  /_/\____/_/ /_/____/\__/\___/_/        
                                            
{Fore.YELLOW}    HACKERONE VULNERABILITY SCANNER - MONSTER EDITION
{Style.RESET_ALL}"""
    print(banner)
    print(f"{Fore.CYAN}[*] Created by Antigravity under the direction of USER")
    print(f"{Fore.CYAN}[*] Ethical Hacking Tool - Use responsibly on authorized targets only.\n")

def print_status(message, status="INFO"):
    if status == "INFO":
        print(f"{Fore.BLUE}[*] {message}")
    elif status == "SUCCESS":
        print(f"{Fore.GREEN}[+] {message}")
    elif status == "WARNING":
        print(f"{Fore.YELLOW}[!] {message}")
    elif status == "VULN":
        print(f"{Fore.RED}[VULNERABILITY] {message}")
    elif status == "ERROR":
        print(f"{Fore.RED}[ERROR] {message}")

def get_input(prompt):
    return input(f"{Fore.WHITE}{prompt}: ")

def ensure_protocol(url):
    if not url.startswith("http://") and not url.startswith("https://"):
        return "https://" + url
    return url

# ------------------------------------------------------------------------------
# SCANNERS
# ------------------------------------------------------------------------------
class MonsterScanner:
    def __init__(self, target):
        self.target = ensure_protocol(target)
        self.domain = urlparse(self.target).netloc
        self.findings = []
        self.session = requests.Session()
        self.session.headers.update(HEADERS_USER_AGENT)
        self.screenshot_data = None
        try:
            self.ip = self.session.get('https://api.ipify.org', timeout=5).text
        except:
            self.ip = "Unknown (Check manually)"

    def run(self):
        print_status(f"Starting generic scan on: {self.target}", "INFO")
        print_status(f"Scanner IP: {self.ip}", "INFO")
        
        try:
            # Main Request
            response = self.session.get(self.target, timeout=10)
            print_status(f"Target is UP (Status: {response.status_code})", "SUCCESS")
            
            # Capture Screenshot early
            self.capture_screenshot()

            # 1. Analyze Headers
            self.analyze_headers(response.headers)
            
            # 2. Check CORS
            self.check_cors(response.url)
            
            # 3. Info Disclosure
            self.check_info_disclosure(response.headers)
            
            # 4. Sensitive Files
            self.scan_sensitive_files()
            
            # 5. Generate Report
            self.generate_report(response.headers)
            
        except requests.exceptions.RequestException as e:
            print_status(f"Connection failed: {e}", "ERROR")

    def capture_screenshot(self):
        print_status("Capturing screenshot with Playwright...", "INFO")
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                page = browser.new_page()
                page.goto(self.target, timeout=20000)
                # Wait a bit for render
                page.wait_for_timeout(2000) 
                self.screenshot_data = page.screenshot()
                browser.close()
            print_status("Screenshot captured successfully.", "SUCCESS")
        except Exception as e:
            print_status(f"Screenshot failed: {e}", "ERROR")
            self.screenshot_data = None

    def analyze_headers(self, headers):
        print_status("Analyzing Security Headers...", "INFO")
        
        # Check X-Frame-Options (Clickjacking)
        if 'X-Frame-Options' not in headers:
            self.generate_clickjacking_poc()
            self.add_finding(
                title="Clickjacking via Missing X-Frame-Options",
                weakness_name="Clickjacking (CWE-1021)",
                cwe="CWE-1021",
                severity="Medium",
                cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:N/A:N",
                description="The application is missing the 'X-Frame-Options' HTTP header. This header controls whether a browser should be allowed to render a page in a <frame>, <iframe>, <embed> or <object>. By not setting this header, the application is vulnerable to Clickjacking attacks where an attacker can trick a user into clicking on invisible overlays.",
                impact="An attacker can induce users to perform actions that they do not intend to perform rather than the ones they think they are performing. This can lead to unauthorized transactions, data modification, or information disclosure.",
                remediation="Implement the 'X-Frame-Options' header with a value of 'DENY' or 'SAMEORIGIN'. Alternatively, use the 'Content-Security-Policy' header with the 'frame-ancestors' directive.",
                evidence=f"Target: {self.target}\nMissing Header: X-Frame-Options",
                steps_reproduce=[
                    f"1. Navigate to {self.target}",
                    "2. Inspect the HTTP response headers.",
                    "3. Observe that the 'X-Frame-Options' header is missing.",
                    f"4. create an HTML file with an iframe pointing to {self.target}.",
                    "5. Open the HTML file in a browser and observe that the site loads within the frame."
                ],
                references=[
                    "https://portswigger.net/web-security/clickjacking",
                    "https://cheatsheetseries.owasp.org/cheatsheets/Clickjacking_Defense_Cheat_Sheet.html"
                ]
            )
            print_status("Missing X-Frame-Options (Potential Clickjacking)", "VULN")
        else:
            print_status("X-Frame-Options is present", "SUCCESS")

        # Check HSTS
        if 'Strict-Transport-Security' not in headers:
            self.add_finding(
                title="Insufficient Transport Layer Protection (HSTS)",
                weakness_name="Insufficient Transport Layer Protection (CWE-319)",
                cwe="CWE-319",
                severity="Low",
                cvss_vector="CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:N",
                description="The application does not enforce HTTP Strict Transport Security (HSTS). This mechanism enforces the use of HTTPS and prevents downgrade attacks.",
                impact="Attackers can intercept communication (Man-in-the-Middle) by downgrading the connection from HTTPS to HTTP, allowing them to steal credentials, session cookies, or sensitive data.",
                remediation="Configure the server to return the 'Strict-Transport-Security' header with a long 'max-age' (e.g., 31536000) and 'includeSubDomains'.",
                evidence=f"Target: {self.target}\nMissing Header: Strict-Transport-Security",
                steps_reproduce=[
                    f"1. Send a GET request to {self.target}",
                    "2. Inspect the response headers.",
                    "3. Observe the absence of the 'Strict-Transport-Security' header."
                ],
                references=[
                    "https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Strict_Transport_Security_Cheat_Sheet.html"
                ]
            )
            print_status("Missing HSTS", "WARNING")
        
        # Check X-Content-Type-Options
        if 'X-Content-Type-Options' not in headers or headers['X-Content-Type-Options'] != 'nosniff':
             self.add_finding(
                title="Missing X-Content-Type-Options Header",
                weakness_name="Protection Mechanism Failure (CWE-693)",
                cwe="CWE-693",
                severity="Low",
                cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:L/I:N/A:N",
                description="The application does not set the 'X-Content-Type-Options' header to 'nosniff'. This allows older browsers to perform MIME-sniffing, which can lead to Cross-Site Scripting (XSS) if an attacker can upload a file with a safe extension but malicious content.",
                impact="An attacker could bypass XSS protections by uploading a file with a non-HTML extension (like .txt or .jpg) but containing HTML/JS, which the browser would then execute.",
                remediation="Set the 'X-Content-Type-Options' header to 'nosniff' in all HTTP responses.",
                evidence=f"Target: {self.target}\nMissing or Incorrect Header: X-Content-Type-Options",
                steps_reproduce=[
                    f"1. Send a request to {self.target}",
                    "2. Observe that the 'X-Content-Type-Options' header is missing or not set to 'nosniff'."
                ],
                references=[
                    "https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/X-Content-Type-Options"
                ]
            )
             print_status("Missing X-Content-Type-Options", "WARNING")

    def check_cors(self, url):
        print_status("Checking CORS configuration...", "INFO")
        # Simple reflection test
        origin = "https://evil.com"
        try:
            r = self.session.get(url, headers={'Origin': origin}, timeout=5)
            acao = r.headers.get('Access-Control-Allow-Origin')
            if acao == '*' or acao == origin:
                self.add_finding(
                    title="CORS Misconfiguration (Arbitrary Origin Allowed)",
                    weakness_name="Cross-Origin Resource Sharing (CORS) Misconfiguration (CWE-942)",
                    cwe="CWE-942",
                    severity="High",
                    cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:N/A:N",
                    description=f"The application has a CORS entry that trusts arbitrary origins. It reflects the Origin header '{origin}' or uses the wildcard '*'. This configuration allows any malicious site to read sensitive data from the vulnerable application on behalf of a user.",
                    impact="A malicious website could make authenticated requests to the vulnerable application and read the responses (data exfiltration). This bypasses the Same-Origin Policy.",
                    remediation="Configure the server to only allow trusted origins in the 'Access-Control-Allow-Origin' header. Do not reflect the 'Origin' header blindly.",
                    evidence=f"Request Origin: {origin}\nResponse Access-Control-Allow-Origin: {acao}",
                    steps_reproduce=[
                        f"1. Send a request to {url} with the header 'Origin: https://evil.com'.",
                        "2. Observe the response header 'Access-Control-Allow-Origin'.",
                        f"3. Note that it reflects '{acao}', honoring the arbitrary origin."
                    ],
                    references=[
                        "https://portswigger.net/web-security/cors",
                        "https://cheatsheetseries.owasp.org/cheatsheets/Cross-Origin_Resource_Sharing_Cheat_Sheet.html"
                    ]
                )
                print_status(f"CORS Vulnerability Found! (Origin: {acao})", "VULN")
        except:
            pass

    def check_info_disclosure(self, headers):
        print_status("Checking Information Disclosure...", "INFO")
        keys = ['Server', 'X-Powered-By', 'X-AspNet-Version']
        for k in keys:
            if k in headers:
                val = headers[k]
                self.add_finding(
                    title=f"Information Disclosure via {k} Header",
                    weakness_name="Information Exposure (CWE-200)",
                    cwe="CWE-200",
                    severity="Info",
                    cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
                    description=f"The application discloses its software version or technology stack via the '{k}' HTTP header. This information can help attackers tailor specific exploits.",
                    impact="Disclosing version information allows attackers to map the technology stack and search for specific CVEs or exploits affecting that version.",
                    remediation=f"Configure the web server to suppress the '{k}' header or display a generic value.",
                    evidence=f"Header: {k}\nValue: {val}",
                    steps_reproduce=[
                        f"1. Send a request to {self.target}",
                        f"2. Inspect the response headers.",
                        f"3. Observe the '{k}' header disclosing version information."
                    ],
                    references=[
                        "https://cheatsheetseries.owasp.org/cheatsheets/Information_Leakage_Prevention_Cheat_Sheet.html"
                    ]
                )
                print_status(f"Disclosed {k}: {val}", "WARNING")

    def scan_sensitive_files(self):
        print_status("Scanning for Sensitive Files...", "INFO")
        for f in SENSITIVE_FILES:
            target_url = urljoin(self.target, f)
            try:
                r = self.session.get(target_url, timeout=3, allow_redirects=False)
                if r.status_code == 200:
                    print_status(f"Found accessible file: {target_url}", "WARNING")
                    self.add_finding(
                        title=f"Sensitive File Exposure: {f}",
                        weakness_name="Information Exposure (CWE-200)",
                        cwe="CWE-200",
                        severity="Medium",
                        cvss_vector="CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N",
                        description=f"The sensitive file '{f}' is publicly accessible. This file may contain configuration details, source code references, or other sensitive information.",
                        impact="Exposure of this file could reveal sensitive configuration details, database credentials, or source code structure, facilitating further attacks.",
                        remediation="Ensure that sensitive files are not reachable from the web root and return a 403 Forbidden or 404 Not Found status.",
                        evidence=f"URL: {target_url}\nStatus Code: 200 OK",
                        steps_reproduce=[
                            f"1. Navigate to {target_url} in a browser or via curl.",
                            "2. Observe that the file content is returned with a 200 OK status."
                        ],
                        references=[
                            "https://owasp.org/www-project-top-ten/2017/A3_2017-Sensitive_Data_Exposure"
                        ]
                    )
            except:
                pass

    def add_finding(self, title, weakness_name, cwe, severity, cvss_vector, description, impact, remediation, evidence, steps_reproduce, references):
        self.findings.append({
            'title': title,
            'weakness_name': weakness_name,
            'cwe': cwe,
            'severity': severity,
            'cvss_vector': cvss_vector,
            'description': description,
            'impact': impact,
            'remediation': remediation,
            'evidence': evidence,
            'steps_reproduce': steps_reproduce,
            'references': references
        })

    def generate_clickjacking_poc(self):
        poc_filename = f"poc_clickjacking_{self.domain}.html"
        content = f"""
<html>
    <head><title>Clickjacking PoC - {self.target}</title></head>
    <body>
        <h1>Clickjacking PoC for {self.target}</h1>
        <p>If you can see the site below, it is vulnerable to Clickjacking.</p>
        <iframe src="{self.target}" width="800" height="600"></iframe>
    </body>
</html>
        """
        self.save_artifact(poc_filename, content)
        print_status(f"Generated Clickjacking PoC: {poc_filename}", "SUCCESS")

    def save_artifact(self, filename, content):
        # Determine output folder relative to script location
        script_dir = os.path.dirname(os.path.abspath(__file__))
        date_str = datetime.datetime.now().strftime("%Y-%m-%d")
        folder = os.path.join(script_dir, "Reports", f"{self.domain}_{date_str}")
        
        if not os.path.exists(folder):
            os.makedirs(folder)
        
        path = os.path.join(folder, filename)
        with open(path, "w", encoding='utf-8') as f:
            f.write(content)
        return path

    def save_binary_artifact(self, filename, content):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        date_str = datetime.datetime.now().strftime("%Y-%m-%d")
        folder = os.path.join(script_dir, "Reports", f"{self.domain}_{date_str}")
        if not os.path.exists(folder):
            os.makedirs(folder)
        
        path = os.path.join(folder, filename)
        with open(path, "wb") as f:
            f.write(content)
        return path

    def generate_report(self, raw_headers):
        if not self.findings:
            print_status("No major findings to report.", "INFO")
            return

        print_status(f"Generating {len(self.findings)} Individual HackerOne Reports...", "INFO")
        
        # Save screenshot if available
        screenshot_filename = ""
        if self.screenshot_data:
            screenshot_filename = f"screenshot_{self.domain}.png"
            self.save_binary_artifact(screenshot_filename, self.screenshot_data)
        
        # CVSS Mapping
        cvss_map = {
            'AV:N': 'Network', 'AV:A': 'Adjacent', 'AV:L': 'Local', 'AV:P': 'Physical',
            'AC:L': 'Low', 'AC:H': 'High',
            'PR:N': 'None', 'PR:L': 'Low', 'PR:H': 'High',
            'UI:N': 'None', 'UI:R': 'Required',
            'S:U': 'Unchanged', 'S:C': 'Changed',
            'C:N': 'None', 'C:L': 'Low', 'C:H': 'High',
            'I:N': 'None', 'I:L': 'Low', 'I:H': 'High',
            'A:N': 'None', 'A:L': 'Low', 'A:H': 'High'
        }

        for idx, finding in enumerate(self.findings, 1):
            # Safe filename
            safe_title = "".join(c for c in finding['title'] if c.isalnum() or c in (' ', '_', '-')).strip().replace(" ", "_")
            report_filename = f"Report_{idx:02d}_{safe_title}.md"
            
            # Format steps
            formatted_steps = "\n".join(finding['steps_reproduce'])
            # Format references
            formatted_refs = "\n".join([f"* {ref}" for ref in finding['references']])
            
            # Parse CVSS
            vector_parts = finding['cvss_vector'].split('/')
            cvss_details = []
            for part in vector_parts:
                if part in cvss_map:
                    metric = part.split(':')[0]
                    val = cvss_map[part]
                    # Map metric code to name
                    metric_name = {
                        'AV': 'Attack Vector', 'AC': 'Attack Complexity', 'PR': 'Privileges Required',
                        'UI': 'User Interaction', 'S': 'Scope', 'C': 'Confidentiality',
                        'I': 'Integrity', 'A': 'Availability'
                    }.get(metric, metric)
                    cvss_details.append(f"- **{metric_name}**: {val}")
            
            cvss_block = "\n".join(cvss_details)



            md_content = f"""# REPORT FOR: {finding['title']}

## Metadata
- **Asset**: {self.domain}
- **Weakness**: {finding['weakness_name']}
- **Severity**: {finding['severity']}
- **CVSS 3.1 Vector**: `{finding['cvss_vector']}`

### CVSS Calculation
{cvss_block}

--------------------------------------------------------------------------------
(COPY PASTE SECTIONS BELOW)

Title:
{finding['title']}

Description:

## Summary:
{finding['description']}

## {self.domain} test accounts used for testing:
{self.domain} accounts: None (Unauthenticated Scan)
IP address: {self.ip}

## Steps to Reproduce:
{formatted_steps}

**Request/Response:**
```http
{finding['evidence']}
```



Impact:

## Summary:
{finding['impact']}
"""
            path = self.save_artifact(report_filename, md_content)
            print_status(f"Generated Report: {path}", "SUCCESS")

# ------------------------------------------------------------------------------
# ENTRY POINT
# ------------------------------------------------------------------------------
if __name__ == "__main__":
    print_banner()
    if len(sys.argv) > 1:
        target_url = sys.argv[1]
    else:
        target_url = get_input("Enter Target URL (e.g., example.com)")
    
    scanner = MonsterScanner(target_url)
    scanner.run()
