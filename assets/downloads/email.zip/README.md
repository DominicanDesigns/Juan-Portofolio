# 📧 Email Automation & Lead Outreach

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

Sends personalized HTML emails to a list of contacts (`contacts.csv`) using Gmail/Outlook SMTP and `Jinja2` templates.

### 🚀 Usage

1.  **Config**: Open `mail_sender.py` and set your `EMAIL_ADDRESS` and `EMAIL_PASSWORD`.
    - _Note_: Use an **App Password** for Gmail.
2.  **Contacts**: Edit `contacts.csv` with real data.
3.  **Run**:
    ```bash
    python mail_sender.py
    ```

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Envía correos electrónicos HTML personalizados a una lista de contactos (`contacts.csv`) utilizando SMTP (Gmail, Outlook) y plantillas `Jinja2`.

### 🚀 Uso

1.  **Configuración**: Abre `mail_sender.py` y pon tu `EMAIL_ADDRESS` (correo) y `EMAIL_PASSWORD` (contraseña).
    - _Nota_: Si usas Gmail, **debes** usar una "Contraseña de Aplicación" (App Password), no tu contraseña normal.
2.  **Contactos**: Edita el archivo `contacts.csv` con tus clientes reales.
3.  **Ejecutar**:
    ```bash
    python mail_sender.py
    ```
