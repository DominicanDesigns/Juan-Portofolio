# TikTok Video Savior

**Description**: Advanced web scraping automation
**Target Audience**: Data Analysts
**Tech Stack**: Python, Selenium/BS4
**Type**: WEB Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
