# AI Interview Prep Tool

**Description**: Preguntas por rol  
**Target Audience**: Estudiantes  
**Tech Stack**: Python, NLP  
**Difficulty**: Fácil | 4 días  
**Monetization**: Pago único  
**Where to Sell**: Etsy  
**Value Proposition**: Nervios en entrevistas

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
