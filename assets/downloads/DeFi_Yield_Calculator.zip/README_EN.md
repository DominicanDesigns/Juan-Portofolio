# DeFi Yield Calculator

**Description**: Financial analysis and tracking
**Target Audience**: Traders/Investors
**Tech Stack**: Python, Pandas, APIs
**Type**: WEB Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
