# AI Code Reviewer

**Description**: Revisa código  
**Target Audience**: Devs  
**Tech Stack**: Python  
**Difficulty**: Difícil | 10 días  
**Monetization**: Licencia  
**Where to Sell**: Gumroad  
**Value Proposition**: Errores

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
