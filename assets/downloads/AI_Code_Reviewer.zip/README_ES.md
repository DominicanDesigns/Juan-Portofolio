# AI Code Reviewer

**Descripción**: Revisa código  
**Público Objetivo**: Devs  
**Tecnología**: Python  
**Dificultad**: Difícil | 10 días  
**Monetización**: Licencia  
**Precio Sugerido**: $120  
**Dónde Vender**: Gumroad  
**Propuesta de Valor**: Errores

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
