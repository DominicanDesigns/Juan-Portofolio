import asyncio
import json
import os
from playwright.async_api import async_playwright

def load_config():
    with open('config.json', 'r') as f:
        return json.load(f)

CONFIG = load_config()

class SocialMediaBot:
    def __init__(self):
        self.browser = None
        self.context = None
        self.page = None
        self.headless = CONFIG.get('headless', False)
        self.platform_url = CONFIG['platform_url']
    
    async def start(self):
        try:
            p = await async_playwright().start()
            self.browser = await p.chromium.launch(headless=self.headless)
            
            if os.path.exists("auth.json"):
                self.context = await self.browser.new_context(storage_state="auth.json")
                print("🍪 Session loaded / Sesión cargada.")
            else:
                self.context = await self.browser.new_context()
            
            self.page = await self.context.new_page()
            print("🚀 Browser started.")
        except Exception as e:
            print(f"❌ Error: {e}")

    async def login(self):
        try:
            await self.page.goto(self.platform_url)
            await self.page.wait_for_load_state('networkidle')

            if await self.page.is_visible(CONFIG['selectors']['feed_check']):
                print("✅ Already logged in / Ya iniciaste sesión.")
                return

            print("🔑 Logging in...")
            await self.page.fill(CONFIG['selectors']['username_field'], CONFIG['username'])
            await self.page.fill(CONFIG['selectors']['password_field'], CONFIG['password'])
            
            await self.page.click(CONFIG['selectors']['submit_button'])
            await self.page.wait_for_load_state('networkidle')

            try:
                await self.page.wait_for_selector(CONFIG['selectors']['feed_check'], timeout=10000)
                print("✅ Login Successful!")
                await self.context.storage_state(path="auth.json")
                print("💾 Session saved / Sesión guardada.")
            except:
                print("❌ Login failed. Check credentials or 2FA.")

        except Exception as e:
            print(f"❌ Error during login: {e}")

    async def stop(self):
        if self.browser:
            await self.browser.close()

async def main():
    bot = SocialMediaBot()
    await bot.start()
    await bot.login()
    
    if not CONFIG.get('headless', True):
        await asyncio.sleep(5)
    
    await bot.stop()

if __name__ == "__main__":
    asyncio.run(main())
