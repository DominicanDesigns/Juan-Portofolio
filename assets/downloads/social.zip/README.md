# 🤖 Social Media Automation Bot

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

A robust bot structure using **Playwright**. It handles login, saves your session (cookies) so you don't have to log in deeply every time, and is safe and undetected.

### 🛠️ Configuration

1.  **Dependencies**: `pip install -r requirements.txt` and `playwright install chromium`.
2.  **Config**: Edit `config.json` with your username, password, and the `selectors` for the specific site (Instagram, Twitter/X, etc.).

### 🚀 Usage

```bash
python social_bot.py
```

- **First Run**: Watch the browser. If a CAPTCHA appears, solve it manually. The bot will save your login to `auth.json`.
- **Next Runs**: It will auto-load your session.

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Un bot robusto que utiliza **Playwright**. Maneja el inicio de sesión, guarda tu sesión (cookies) para que no tengas que loguearte cada vez, y está diseñado para ser seguro.

### 🛠️ Configuración

1.  **Dependencias**: `pip install -r requirements.txt` y `playwright install chromium`.
2.  **Configuración**: Edita `config.json` con tu usuario, contraseña y los `selectors` (selectores CSS) del sitio específico (Instagram, Twitter, etc.).

### 🚀 Uso

```bash
python social_bot.py
```

- **Primera ejecución**: Observa el navegador. Si aparece un CAPTCHA, resuélvelo manualmente. El bot guardará tu sesión en `auth.json`.
- **Siguientes ejecuciones**: Cargará tu sesión automáticamente sin pedir contraseña.
