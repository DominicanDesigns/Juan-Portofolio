# AI Text Classifier

**Descripción**: Clasifica documentos  
**Público Objetivo**: Empresas  
**Tecnología**: Python, ML  
**Dificultad**: Media | 6 días  
**Monetización**: Licencia  
**Precio Sugerido**: $50  
**Dónde Vender**: Directo  
**Propuesta de Valor**: Organización

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
