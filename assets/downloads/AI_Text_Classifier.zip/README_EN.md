# AI Text Classifier

**Description**: Clasifica documentos  
**Target Audience**: Empresas  
**Tech Stack**: Python, ML  
**Difficulty**: Media | 6 días  
**Monetization**: Licencia  
**Where to Sell**: Directo  
**Value Proposition**: Organización

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
