# 🛒 E-commerce Price Monitor

[English](#english) | [Español](#español)

---

<a name="english"></a>

## 🇬🇧 English Manual

### Overview

Tracks product prices from URLs in `products.csv` and alerts you when they drop below a target price.

### 🚀 Usage

1.  **Dependencies**: `pip install -r requirements.txt`.
2.  **Products**: Edit `products.csv` with Name, URL, and TargetPrice.
3.  **Selectors**: Update `price_element = soup.select_one(...)` in the script to match your specific shop (Amazon/eBay selectors differ).
4.  **Run**:
    ```bash
    python price_monitor.py
    ```

---

<a name="español"></a>

## 🇪🇸 Manual en Español

### Descripción General

Monitorea los precios de los productos listados en `products.csv` y te avisa cuando bajan por debajo de tu precio objetivo.

### 🚀 Uso

1.  **Dependencias**: `pip install -r requirements.txt`.
2.  **Productos**: Edita `products.csv` agregando Nombre, URL y Precio Objetivo (TargetPrice).
3.  **Selectores**: Actualiza la línea `price_element = soup.select_one(...)` en el script. Cada tienda (Amazon, MercadoLibre, etc.) tiene un código distinto, así que debes inspeccionar el elemento del precio en tu navegador y poner la clase correcta.
4.  **Ejecutar**:
    ```bash
    python price_monitor.py
    ```
