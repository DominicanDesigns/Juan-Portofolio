import requests
from bs4 import BeautifulSoup
import csv
import time
import schedule
from datetime import datetime
import os

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9"
}

PRODUCTS_FILE = 'products.csv'

def get_price(url):
    try:
        response = requests.get(url, headers=HEADERS)
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # EXAMPLE SELECTOR - CHANGE THIS
        price_element = soup.select_one('.price, #price, .product-price, .amount') 
        
        if price_element:
            price_text = price_element.get_text().strip()
            price_clean = price_text.replace('$', '').replace(',', '').replace('€', '')
            return float(price_clean)
        else:
            return None
    except Exception as e:
        print(f"❌ Error fetching {url}: {e}")
        return None

def check_prices():
    print(f"\n🔎 Checking prices at {datetime.now().strftime('%H:%M:%S')}...")
    
    if not os.path.exists(PRODUCTS_FILE):
        print(f"⚠️ {PRODUCTS_FILE} not found.")
        return

    with open(PRODUCTS_FILE, 'r') as f:
        reader = csv.DictReader(f)
        products = list(reader)

    for item in products:
        url = item['URL']
        target_price = float(item['TargetPrice'])
        name = item['Name']

        current_price = get_price(url)

        if current_price:
            print(f"   🔹 {name}: ${current_price} (Target: ${target_price})")
            if current_price <= target_price:
                print(f"🚨 PRICE DROP ALERT! {name} is now ${current_price}!")
        else:
            print(f"   ⚠️ Could not find price for {name}")

def run_scheduler():
    print("⏱️ Price Monitor Started. Press Ctrl+C to stop.")
    check_prices() 
    schedule.every(1).hours.do(check_prices)

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    if not os.path.exists(PRODUCTS_FILE):
        with open(PRODUCTS_FILE, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Name', 'URL', 'TargetPrice'])
            writer.writerow(['Test Product', 'https://web-scraping.dev/product/1', '100.00'])
            print(f"📝 Created dummy {PRODUCTS_FILE}")

    run_scheduler()
