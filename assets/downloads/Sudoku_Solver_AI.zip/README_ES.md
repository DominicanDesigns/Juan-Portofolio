# Sudoku Solver AI

**Descripción**: Entertainment and logic
**Público**: Gamers
**Tecnología**: Python, Pygame/Logic
**Tipo**: Aplicación CLI

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
