# Tinder Swipe Auto

**Description**: Automated interaction bot
**Target Audience**: Community Managers
**Tech Stack**: Python, API
**Type**: CLI Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
