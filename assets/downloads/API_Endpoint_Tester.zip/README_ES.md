# API Endpoint Tester

**Descripción**: Developer productivity tool
**Público**: Developers
**Tecnología**: Python, Utilities
**Tipo**: Aplicación WEB

## Uso
1. `pip install -r requirements.txt`
2. `python main.py`
