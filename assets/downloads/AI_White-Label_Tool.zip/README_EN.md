# AI White-Label Tool

**Description**: Rebrand IA  
**Target Audience**: Agencias  
**Tech Stack**: Python  
**Difficulty**: Difícil | 15 días  
**Monetization**: Comercial  
**Where to Sell**: Directo  
**Value Proposition**: Revender

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
