# AI Chatbot Web

**Description**: Soporte automático  
**Target Audience**: Negocios  
**Tech Stack**: Python, Flask  
**Difficulty**: Media | 7 días  
**Monetization**: Licencia  
**Where to Sell**: Directo  
**Value Proposition**: Atención 24/7

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
