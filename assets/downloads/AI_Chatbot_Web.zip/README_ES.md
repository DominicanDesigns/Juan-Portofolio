# AI Chatbot Web

**Descripción**: Soporte automático  
**Público Objetivo**: Negocios  
**Tecnología**: Python, Flask  
**Dificultad**: Media | 7 días  
**Monetización**: Licencia  
**Precio Sugerido**: $120  
**Dónde Vender**: Directo  
**Propuesta de Valor**: Atención 24/7

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
