# Math Problem Solver

**Description**: Educational utility
**Target Audience**: Students
**Tech Stack**: Python
**Type**: WEB Application

## Usage
1. `pip install -r requirements.txt`
2. `python main.py`
