import pandas as pd
import numpy as np
import os
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

# --- CONFIGURATION ---
INPUT_FILE = 'raw_sales_data.csv'
OUTPUT_FILE = 'Monthly_Sales_Report.xlsx'

def create_dummy_data():
    print("🧪 Creating dummy data / Creando datos de prueba...")
    data = {
        'TransactionID': range(1001, 1021),
        'Date': pd.date_range(start='2024-01-01', periods=20),
        'Product': ['Widget A', 'Widget B', 'Widget A', 'Widget C', 'Widget B'] * 4,
        'Region': ['North', 'South', 'East', 'West', 'North'] * 4,
        'Sales': np.random.randint(100, 1000, size=20),
        'Units': np.random.randint(1, 10, size=20)
    }
    df = pd.DataFrame(data)
    df.loc[5, 'Sales'] = None
    df.to_csv(INPUT_FILE, index=False)
    print(f"✅ Created {INPUT_FILE}")

def process_data():
    print("⚙️ Processing data...")
    if not os.path.exists(INPUT_FILE):
        create_dummy_data()

    df = pd.read_csv(INPUT_FILE)
    df['Sales'] = df['Sales'].fillna(0)
    df['Total Revenue'] = df['Sales'] * df['Units']
    
    summary = df.groupby('Product')[['Sales', 'Units', 'Total Revenue']].sum().reset_index()
    return df, summary

def generate_excel_report(df, summary):
    print(f"📊 Generating Excel report: {OUTPUT_FILE}")
    
    with pd.ExcelWriter(OUTPUT_FILE, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Raw Data', index=False)
        summary.to_excel(writer, sheet_name='Summary', index=False)

    wb = load_workbook(OUTPUT_FILE)
    ws = wb['Summary']
    
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="4F81BD")
    
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    for row in ws.iter_rows(min_row=2, max_col=4, max_row=ws.max_row):
        row[1].number_format = '#,##0.00' 
        row[3].number_format = '$ #,##0.00'

    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        ws.column_dimensions[column].width = (max_length + 2)

    wb.save(OUTPUT_FILE)
    print("✅ Report generated successfully!")

if __name__ == "__main__":
    df, summary = process_data()
    generate_excel_report(df, summary)
