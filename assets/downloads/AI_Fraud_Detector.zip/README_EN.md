# AI Fraud Detector

**Description**: Detecta fraude  
**Target Audience**: Finanzas  
**Tech Stack**: Python, ML  
**Difficulty**: Difícil | 14 días  
**Monetization**: Licencia  
**Where to Sell**: B2B  
**Value Proposition**: Pérdidas

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
