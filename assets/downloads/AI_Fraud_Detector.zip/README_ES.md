# AI Fraud Detector

**Descripción**: Detecta fraude  
**Público Objetivo**: Finanzas  
**Tecnología**: Python, ML  
**Dificultad**: Difícil | 14 días  
**Monetización**: Licencia  
**Precio Sugerido**: $160  
**Dónde Vender**: B2B  
**Propuesta de Valor**: Pérdidas

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
