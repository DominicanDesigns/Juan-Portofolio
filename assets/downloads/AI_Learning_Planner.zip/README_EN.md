# AI Learning Planner

**Description**: Planes de estudio  
**Target Audience**: Estudiantes  
**Tech Stack**: Python  
**Difficulty**: Media | 5 días  
**Monetization**: Freemium  
**Where to Sell**: App  
**Value Proposition**: Desorganización

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python main.py`
