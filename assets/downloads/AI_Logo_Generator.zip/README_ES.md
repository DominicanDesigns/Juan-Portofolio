# AI Logo Generator

**Descripción**: Logos automáticos  
**Público Objetivo**: Startups  
**Tecnología**: Python, CV  
**Dificultad**: Media | 6 días  
**Monetización**: Créditos  
**Precio Sugerido**: $35  
**Dónde Vender**: Web  
**Propuesta de Valor**: Branding caro

## Cómo Ejecutar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar script: `python main.py`
